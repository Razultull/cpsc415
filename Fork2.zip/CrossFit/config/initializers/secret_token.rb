# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
CrossFit::Application.config.secret_token = 'f2741c050142959e223585c89c3617e9aa7fb319f1e3cfe3a220ce1657e5b88b071f17a3693eae402af47c3eb6aa892ac88ee33a5e0955a4f5ac555f616ed316'
