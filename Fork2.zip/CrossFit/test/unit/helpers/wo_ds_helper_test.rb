require 'test_helper'

class WoDsHelperTest < ActionView::TestCase
end
