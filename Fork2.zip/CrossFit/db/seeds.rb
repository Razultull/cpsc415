#---
# Excerpted from "Agile Web Development with Rails",
# published by The Pragmatic Bookshelf.
# Copyrights apply to this code. It may not be used to create training material, 
# courses, books, articles, and the like. Contact us if you are in doubt.
# We make no guarantees that this code is fit for any purpose. 
# Visit http://www.pragmaticprogrammer.com/titles/rails4 for more book information.
#---
#---
# Excerpted from "Agile Web Development with Rails, 4rd Ed.",
# published by The Pragmatic Bookshelf.
# Copyrights apply to this code. It may not be used to create training material, 
# courses, books, articles, and the like. Contact us if you are in doubt.
# We make no guarantees that this code is fit for any purpose. 
# Visit http://www.pragmaticprogrammer.com/titles/rails4 for more book information.
#---
# encoding: utf-8
Gymnasium.delete_all
Gymnasium.create(:Name => "Gold's Gym",
  :StreetAddress => "23 Crazy Street",    
  :City => "Moscow")
  
  Gymnasium.create(:Name => "Ferris Athletic Center",
  :StreetAddress => "300 Summit Street",    
  :City => "Hartford")
  
  Gymnasium.create(:Name => "Brian's",
  :StreetAddress => "1 Infinite Loop",    
  :City => "Cupertino")
  

#---
#:Name, :NumberOfDaysPerWeek, :NumberOfExercises, :TimeNeeded
#---

WoD.delete_all
WoD.create(:Name => "Elliptical Burn", 
           :NumberOfDaysPerWeek => 7, 
           :NumberOfExercises => 5,
           :TimeNeeded => "1 hour")
          
WoD.create(:Name => "Fat Burner", 
           :NumberOfDaysPerWeek => 5, 
           :NumberOfExercises => 7,
           :TimeNeeded => "90 Minutes")

WoD.create(:Name => "Mega Man Abs", 
           :NumberOfDaysPerWeek => 3, 
           :NumberOfExercises => 12,
           :TimeNeeded => "35 hour")