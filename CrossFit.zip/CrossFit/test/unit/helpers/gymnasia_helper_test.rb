require 'test_helper'

class GymnasiaHelperTest < ActionView::TestCase
end
