require 'test_helper'

class WoDTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
